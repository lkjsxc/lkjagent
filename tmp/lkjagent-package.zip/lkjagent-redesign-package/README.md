# lkjagent Redesign Package

This package is the temporary handoff for the next coding agent. Read the project docs first, then use this package as an execution map. The project is a one-owner, one-local-endpoint, one-workspace, one-SQLite daemon. Its best future is a finished state-ledger runtime, not a second control plane.

Primary outcomes:

- improve documentation first;
- keep every authored file below 200 lines and near 512 tokens when practical;
- make durable rows own runtime decisions, prompt frames, tool views, context, effects, observations, artifacts, checks, recovery, proof, and CLI reports;
- make the human CLI attractive without hiding state outside SQLite;
- run deterministic gates and an honest final daemon proof attempt.
