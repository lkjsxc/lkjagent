# Target Design

Runtime loop:

```text
rows -> snapshot -> decision -> prompt or effect -> observation -> event -> rows
```

A persisted runtime decision is the authority for one turn. Prompt grammar, visible tools, admission, effect dispatch, timeout, recovery policy, completion predicates, status, and proof must all agree with that row.

The functional core should remain pure. Reducers, selectors, rendering, parsing, admission, checks, completion, artifact assembly, and fingerprinting should be deterministic functions over plain data. SQLite, filesystem, shell, clock, Docker, terminal, and endpoint operations should remain adapters at crate edges.

Documentation should become more recursively navigable. Each directory keeps one `README.md` table of contents and small child pages. Do not split for vanity; split by ownership. Prefer deletion over flags when a surface is outside scope.

The CLI should borrow terminal ergonomics from modern coding agents: readable status, live watch, concise traces, proof links, command evidence, and easy inspection. Do not borrow hidden state, permissive host execution, or model-owned completion.
