# Work Plan

Slice 1: documentation map. Re-read `docs/README.md`, `docs/current-state.md`, and all contract directories. Fix stale docs, missing READMEs, overlong pages, and contradictions before code.

Slice 2: CLI drift. Add `Log { limit, follow }`, parse `log --follow`, `log --limit N`, and both together. Implement row-backed follow polling. Add parser and CLI tests. Update help and docs.

Slice 3: context fingerprint. Introduce a decision-preparation input carrying the prepared prompt-context fingerprint. Persist it in `runtime_decisions`, `prompt_frames`, and provider exchange rows. Add a focused test proving the values agree.

Slice 4: semantic schema labels. Rename numeric schema suffix labels to semantic labels. Update docs, tests, fixtures, and reducer expectations together.

Slice 5: CLI human UX. Improve `status`, `task show`, `queue show`, `log`, and `watch` around active cells, current decision, prompt frame, tool view, conflicts, artifacts, checks, exchanges, token usage, lease, and recovery.

Slice 6: artifact unit authority. Ensure long writes schedule bounded units explicitly, assemble only after unit checks, create fresh aggregate fingerprints, and add shortfall continuation rows instead of asking for huge completions.

Slice 7: proof. Ensure xtask can collect a proof bundle with state cells, decisions, prompts, admissions, observations, exchanges, artifacts, context, conflicts, suppressions, checks, and gate logs.
