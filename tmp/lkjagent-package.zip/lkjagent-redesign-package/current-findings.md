# Current Findings

The current docs already define the correct product shape: a continuously running personal agent for one owner, one local OpenAI-compatible endpoint, one workspace, and one SQLite store. Runtime authority is moving from a fixed plan ledger to durable state rows and persisted runtime decisions.

Important implemented areas include row-backed queue/task/status surfaces, state-ledger domain types, state tables, runtime decision preparation, prompt-frame rows, provider exchanges, context items, contradiction cells, observations, artifacts, proof sections, Docker gates, and an xtask verification surface.

Concrete gaps to resolve first:

1. The CLI docs expose `log --follow`; the parser accepts only `log --limit N`. Implement follow with tests or remove it from docs after deciding the desired surface.
2. Runtime decisions currently fingerprint an empty context projection. The app already computes a real prompt-context fingerprint; thread it into decision selection, prompt frames, exchanges, status, and recovery tests.
3. Avoid numeric schema suffix naming. Replace existing project-authored schema labels with semantic names where feasible.
4. The owner CLI is useful but thin. Improve status, task trace, proof visibility, bounded logs, queue detail, and watch behavior.
5. Long artifact generation must be truly unit-first: small checked units, deterministic assembly, fresh fingerprints, and durable shortfall continuation.
