# Verification And Final Run

Run focused tests after each slice, then gate upward:

```sh
cargo run -p lkjagent-xtask -- check-docs
cargo run -p lkjagent-xtask -- check-lines
cargo run -p lkjagent-xtask -- check-files
cargo run -p lkjagent-xtask -- check-style
cargo run -p lkjagent-xtask -- quiet test
cargo run -p lkjagent-xtask -- quiet verify
docker compose run --rm verify
```

Never claim a command passed unless it ran in the current checkout. Historical logs are useful fixtures, not current proof.

At the end, run an actual approximately 30 minute daemon attempt. Use endpoint credentials from the environment when available. Start the daemon, send a long structured artifact objective, watch status until terminal state or the time box ends, collect proof, and commit an evidence note.

The evidence note must include command lines, data directory, objective, start and stop timestamps, terminal or still-open state, current decision id, row counts, generated file summary, measured checks, proof bundle path, and exact blocked reason if blocked. Missing endpoint credentials are an honest blocked condition, not proof.
